const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

const db = mysql.createConnection({
  host: 'localhost',
  user: 'adsser_login',
  password: 'Ssaa112233++',
  database: 'adsser_login'
});

db.connect((err) => {
  if (err) {
    throw err;
  }
  console.log('MySQL Connected...');
});

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Routes
app.post('/add-url', (req, res) => {
  const { urls } = req.body;
  const sql = `INSERT INTO myurl (urls) VALUES (?)`;
  
  db.query(sql, [urls], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.send({ status: 'OK' });
  });
});


app.post('/add-sweet', (req, res) => {
  const { sweet } = req.body;
  const sql = `INSERT INTO sweets (sweet) VALUES (?)`;
  
  db.query(sql, [sweet], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.send({ status: 'OK' });
  });
});

app.post('/add-pixel', (req, res) => {
  const { pixels } = req.body;
  const sql = `INSERT INTO pixcel (pixels) VALUES (?)`;
  
  db.query(sql, [pixels], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.send({ status: 'OK' });
  });
});


app.get('/get', (req, res) => {
  const sql = 'SELECT * FROM myurl';
  
  db.query(sql, (err, results) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.send(results);
  });
});



app.get('/api', (req, res) => {
  const sql = 'SELECT * FROM sweets';
  
  db.query(sql, (err, results) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.send(results);
  });
});

app.get('/getpixel', (req, res) => {
  const sql = 'SELECT * FROM pixcel';
  
  db.query(sql, (err, results) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.send(results);
  });
});

app.delete('/delete-pixel/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM pixcel WHERE id = ?';
  
  db.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.send({ status: 'ok' });
  });
});



app.delete('/delete-sweets/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM sweets WHERE id = ?';
  
  db.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.send({ status: 'ok' });
  });
});



app.delete('/delete-myurl/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM myurl WHERE id = ?';
  
  db.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.send({ status: 'ok' });
  });
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
